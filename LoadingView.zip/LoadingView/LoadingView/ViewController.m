//
//  ViewController.m
//  LoadingView
//
//  Created by Mac on 2018/11/27.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "ViewController.h"
#import "JZLoadingViewPacket.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     此加载页会在1秒后才显示，在网络请求中，如果网络状态良好，在1秒内请求完毕并调用
     [[JZLoadingViewPacket shareInstance] jz_hide];
     则不会显示加载页面，提高用户体验
     
     */
    [JZLoadingViewPacket showWithTitle:@"加载中" result:RequestLoading addToView:self.view];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        /*
         手动隐藏时一定要调用此接口
         */
        [[JZLoadingViewPacket shareInstance] jz_hide];
        /*
         调用加载完毕的接口时（如 RequestSuccess，RequestFaild），则会立即显示，并且在1.5秒后自动消失
         */
//        [JZLoadingViewPacket showWithTitle:@"成功" result:RequestSuccess addToView:self.view];
    });
}


@end
