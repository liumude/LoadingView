//
//  ViewController.m
//  LoadingView
//
//  Created by Mac on 2018/11/27.
//  Copyright © 2018年 Mac. All rights reserved.
//

#import "ViewController.h"
#import "JZLoadingViewPacket.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [JZLoadingViewPacket showWithTitle:@"加载中" result:Loading_suffix hasAnimation:YES addToView:self.view];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [JZLoadingViewPacket shareInstance].hidden = YES;
    });
}


@end
