

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    RequestLoading,
    RequestSuccess,
    RequestFaild,
} RequestResult;

@interface JZLoadingViewPacket : UIView


- (void)showWithTitle:(NSString *)title result:(RequestResult)result;

- (void)jz_hide;

+ (JZLoadingViewPacket *)shareInstance;


+ (void)showWithTitle:(NSString *)title result:(RequestResult)result addToView:(UIView *)selfView;

@end
